````dart
//.title
// ─────────────────────────────────────────────────────────────────────────────
// 
// Copyright (C) 2024 - [YOUR NAME HERE]
// 
// This source code is licensed under the [LICENSE NAME] found in the
// LICENSE file in the root directory of this source tree.
// 
// ─────────────────────────────────────────────────────────────────────────────
//.title~
````